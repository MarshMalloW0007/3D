                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2868352
Digital Dial Indicator Mount for Tevo Tornado by AlexSteele is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I acquired a dial indicator from Bangood, so I needed to change the original model to allow for a thicker diameter fitting.  I am providing a file you can bring into fusion360 and edit in case you need a different diameter.  I am also including the .stl for printing straight away if you do not have fusion 360.

This has been revised as of May 3rd and I am pleased with mine!  Now ready to remove the thing in progress tag.

# Print Settings

Printer Brand: TEVO
Printer: Tornado
Rafts: No
Supports: Yes
Infill: 50 percent

Notes: 
I rotate this 90 degrees and use supports.  I am using simplify3d.

# How I Designed This

## Designed in Fusion 360

Downloaded the first file, converted it to DXF, imported mesh into fusion 360, built by eye partially and partially via measurements with a digital caliper.  

If you have fusion360, open the file with extension .f3d  by saying 'new design from file' and fusion brings in the file for you to peruse, the timeline is preserved.  Enjoy!



<iframe src="//www.youtube.com/embed/6ug9PX7dMFk" frameborder="0" allowfullscreen></iframe>