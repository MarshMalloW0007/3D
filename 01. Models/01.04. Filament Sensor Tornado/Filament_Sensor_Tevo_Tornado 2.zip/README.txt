                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3046489
Filament Sensor Tevo Tornado by pfeilmayer is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Using the wiring and instructions from : https://www.thingiverse.com/thing:2780549 by dvilleneuve, I have redesigned the Filament Sensor enclosure to make it more rigid.
It is a work in progress, remixes, redesigns, shares, etc are all welcome.
I included the Inventor Part files so you can edit and mod the case as you please

Visit dvilleneuve's page and see wiring video and instructions for the KW12-3 PCB switch.

Marlin mods :

configuration.h
//       #define FILAMENT_RUNOUT_SENSOR

configuration_adv.h 
//       #if ENABLED(ULTIPANEL)
//       #define ADVANCED_PAUSE_FEATURE
//       #define FILAMENT_CHANGE_UNLOAD_LENGTH 0
//       #define FILAMENT_CHANGE_LOAD_LENGTH 0
//       #define ADVANCED_PAUSE_EXTRUDE_LENGTH 0

pins_RAPMS.h
//       //#define Z_MAX_PIN 19
//       #define FIL_RUNOUT_PIN 19

Youtube tutorial for wiring and Marlin mods  : https://www.youtube.com/watch?v=zTRsTWv_IwA


I glued the cover in 2 points, actualy the cover it is only for design purposes and non-functional, so if it does not bother you don't even need to print it.


I have switched to a more simple design. See thing : https://www.thingiverse.com/thing:3089331


If you like and find any of my "things" useful and you would like to support my work, please feel free to donate through :

Paypal : pfeilmayer1985 [at] yahoo [dot] com

Cryptocurrency :
ETH : 0xEc33aBF3EF4Ec0B2eB88ef45E5A91085a19b9d2A
ETC : 0x66E487E327D95b442FD916049D10df8Cd438fe46
ZEC : t1JrFZ4rbdn51PxTffdewM2rKKePoukSE1W
XRP : rBpT9d7sPmiqTEk4Cmqsby2bTfQdNUXQRW
XMR : 44NWHb8GrGxg5W69Qm1Sh9Fvica2xg79wMahEHPsC8yUR3DkCDsz7uFWbwaVe4vUMveKAzAiA4j8xgUi29TpKXpm3yz5F5X

Thank you !

# Print Settings

Printer Brand: TEVO
Printer: Tornado
Rafts: Yes
Supports: Yes
Infill: 10%