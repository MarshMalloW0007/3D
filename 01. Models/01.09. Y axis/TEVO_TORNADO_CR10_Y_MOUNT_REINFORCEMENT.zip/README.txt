                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2734468
TEVO TORNADO CR10 Y MOUNT REINFORCEMENT by infectedfpv26 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A simple Y axis mount to reinforce the stepper motor with adjustable Screw.
MOVE THE  Z LIMIT SWITCH FORWARD TO AVOID HITTING THE BED WITH THE NEW BRACKET

You will need.

2 m3 screws length 42.5mm each
2 m3 screws length 7mm each
1 m5 screw length 12mm
1 half T nut M5

It works just perfect.

attached are Gcode and stl files.
Inland PLA 1.75mm

REMEMBER USE AT LEAST 90% INFILL

if you want to print it right away just upload the gcode file to the sdcard and its done.

# Print Settings

Printer: Tevo Tornado
Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.2
Infill: 90%