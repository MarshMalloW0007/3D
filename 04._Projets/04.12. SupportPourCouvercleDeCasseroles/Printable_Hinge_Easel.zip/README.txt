                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2221374
Printable Hinge Easel by akshay_d21 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Printable Hinged Easel is really a multipurpose Thing. You can use this to display photos, cards, Mobile Phone/iPads/Tablets on tables. 

The best thing is that, you don't need to print this thing as separate parts. This design is compatible to be printed in one go. 

Curious, George? The tolerance is 250 microns inside the hinge. 

<h4><b>One nifty idea is to use your old iPhone or and iPad as an digital photo frame. How cool would that be?!</b></h4>

<i><b>Please note:</b> The design may need some subtle changes if you choose to re-scale it in your 3D-slicer or some other CAD compatible program. The hinge is designed to work effortlessly with the set parameters. Re-scaling will not render it obsolete but the hinge might be loose or tight depending on the scaling factor.
Also, the product photos show a slightly scaled down version of the original model. The original model will have a smoother rotation.</i>

<i>Consider supporting my designs on Patreon, here:  https://www.patreon.com/akshayd21</i>
Thank you! 

<b> Model Update [06/04/2018]: </b> An easier model has been added. Print in place and usable without any kind of assembly. 

# Print Settings

Rafts: Doesn't Matter
Supports: Doesn't Matter
Infill: 33%

Notes: 
User <i><a href="https://www.thingiverse.com/amcolley/about/">amcolley's</a></i> question (see comments) compelled me to add this section to the Thing's page. The hinge is a live joint and needs to work as seamlessly as possible. Thus you need to align the easel upright while slicing and then printing. This will make your work as an end-user and the printer's job as a machine much more easier! 
Hope this helps.