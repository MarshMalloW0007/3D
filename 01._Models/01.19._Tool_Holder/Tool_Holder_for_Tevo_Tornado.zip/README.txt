                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2754906
Tool Holder for Tevo Tornado by ianj001 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a tool holder for the tool kit that comes with the Tevo Tornado. I always find myself looking for the stuff and now it's all sitting right next to the printer. It uses the frame to hold it up. I may do a couple of iterations of this but for now, this one works pretty well. You may have to reopen the holes if your bridging fills them in a bit. I printed it on it's side with no supports.

**UPDATE** I created a second version with two rails to hold the tools more upright. You can choose which one to make, they are basically the same with just the second rail added on the update.

This should work on a CR-10 as the frame is the same.

If you make one please publish a make it's what keeps me publishing to Thingiverse.

# Print Settings

Printer: Tevo Tornado
Rafts: No
Supports: No
Resolution: 0.2 layers
Infill: 30%

Notes: 
I printed in PLA using 205 C nozzle temp and 65 C bed temp for first layer then
195 C nozzle temp and 55 C bed temp for the rest of the print.

# Post-Printing

## Clean up

You may need to clean out the holes depending on how good your bridging is. I printed this on its side with no supports that means the holes are bridged. The larger holes seem to do better than the smaller holes.

# How I Designed This

## Quick mash up

I wanted to tidy up the tools, I was fed up with digging around in the zip lock back to find the right Allen key. I designed the legs and one hold first, I did four iterations to get it to sit right in the extruded frame. Once I was happy with that I made it big enough to put all the tools in. I measure the outside of the spanner and the Allen keys to get the hole/slot sizes.
I designed the whole thing in Fusion 360, it's a fairly simple thing so it took 2 sketches and a few extrudes.