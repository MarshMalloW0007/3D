                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2780549
Filament Sensor Tevo Tornado by dvilleneuve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a filament sensor for the tevo tornado.
Print it, put a KW12-3 PCB switch on it, screw it on the X axis screw (on the extra part of the bolt), connect the cable to Z+, change the FW and you're good to go !

configuration.h
  \#define FILAMENT_RUNOUT_SENSOR

configuration_adv.h
  \#if ENABLED(ULTIPANEL)
  \#define ADVANCED_PAUSE_FEATURE
  \#define FILAMENT_CHANGE_UNLOAD_LENGTH 0
  \#define FILAMENT_CHANGE_LOAD_LENGTH 0 
  \#define ADVANCED_PAUSE_EXTRUDE_LENGTH 0 

pins_RAPMS.h
  //\#define Z_MAX_PIN          19
  \#define FIL_RUNOUT_PIN      19