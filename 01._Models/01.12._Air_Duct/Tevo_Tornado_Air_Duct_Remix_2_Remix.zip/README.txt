                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2766189
Tevo Tornado Air Duct Remix 2 Remix by barrettford is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

A remix of [Jeffware's Tevo Tornado Air Duct Remix 2](https://www.thingiverse.com/thing:2734929) which is a remix of [DGPdesign's Tevo Tornado Fan Duct](https://www.thingiverse.com/thing:2552292).

I have some rubber washers underneath the heads of the bed screws to prevent them from turning when I turn the leveling knobs.  These washers cause the heads to poke up a bit, which hit the fan duct during bed leveling (only the front left).  Obviously, this interference is unacceptable.  I cut off the corner to clear the screw head, and then decided to make the duct basically symmetrical.

# Print Settings

Printer: Tevo Tornado
Rafts: Doesn't Matter
Supports: No
Resolution: .2
Infill: 100%

Notes: 
I printed it as Jeffware suggests, but I don't see why you couldn't use whatever infill you wanted.

# Post-Printing

Some of the bridging may sag, but it is easy enough to fix that with a hobby knife or file.  Just make sure the ducts allow straight airflow.

# How I Designed This

Imported [Jeffware's Tevo Tornado Air Duct Remix 2](https://www.thingiverse.com/thing:2734929) into OpenSCAD and chopped away.