                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3520300
Oral-B Toothbrush Stand (simple) by regularlabs is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A remix of https://www.thingiverse.com/thing:1478249

I made the stand simpler and lighter.
This one doesn't catch any water (or whatever other goo is dripping from your toothbrush).

I found the remix with the drain (https://www.thingiverse.com/thing:3325238) too complex and big.

I use this on the shelve in the shower. So I don't mind any toothpaste running down the sides of it.

# Print Settings

Printer Brand: Creality
Printer: Ender 3 Pro
Rafts: No
Supports: No
Resolution: 0.2
Infill: 50%

Notes: 
Resolution can also be lower, if you want finer details.

I first printed at 25% infill, but the little thingy on the top broke off at some point.
With 50% infill it seems much stronger.