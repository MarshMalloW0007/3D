                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2707374
Circular Fan Duct - Tevo Tornado - Look no further! by manantler is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a remix of another Circular Fan Duct by Darry for the Tevo Tornado.  I was having issues with the one Darry made because the bottom was rubbing up on my prints in certain areas and ruining them.  I made this one thinner and square to better fit underneath the carriage without touching prints.  Works really well so far, no issues.

Walls and top/bottom thickness 1.2mm

PLA works great for this, higher temperature resistant materials are better, nut I haven't had any warping.

Let me know if you see anything that can be improved.  This is my first time doing any design, I purchased my first 3d printer a week ago and have been printing non-stop since then.

Used TinkerCAD

# Print Settings

Printer: Tevo Tornado
Rafts: No
Supports: No
Resolution: 0.3
Infill: 40