                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2363927
TEVO 202020 Test Cube by RVTMSW is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

NOT JUST ANOTHER TEST CUBE!
LET'S DO IT!

<b>Update:</b>
For those who are not a cantilever junkie, I made a novice model.

Please share what you make.


# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/80/3a/4f/8d/57/01.jpg)
1.5x Scaled Up: PLA 0.2mm at 45mm/s

![Alt text](https://cdn.thingiverse.com/assets/3d/3b/78/65/57/04.jpg)
Front - PLA 0.2mm at 45mm/s

![Alt text](https://cdn.thingiverse.com/assets/84/b9/27/ef/7f/05.jpg)
Back - PLA 0.2mm at 45mm/s

![Alt text](https://cdn.thingiverse.com/assets/08/98/f2/7f/6b/03.jpg)
TE

![Alt text](https://cdn.thingiverse.com/assets/af/69/2b/9f/dc/02.jpg)
VO