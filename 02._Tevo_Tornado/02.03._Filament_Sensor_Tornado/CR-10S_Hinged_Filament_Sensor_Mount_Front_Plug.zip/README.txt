                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2791872
CR-10S Hinged Filament Sensor Mount (Front Plug) by RickB is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

** I sold my CR-10S, so I will not be doing any more development / revisions to these file.**

CR-10S Hinged Filament Sensor Mount (Front Plug)
https://www.thingiverse.com/thing:2791872

CR-10S Hinged Filament Sensor Mount (Bottom Plug)
https://www.thingiverse.com/thing:2826099

Lets be honest. The filament runout sensor is a great addition to the Creality CR-10S, but the factory slide-on mount that Creality supplies sucks. I download and printed several other designs from here and just wasn't happy with the alignment or functionally of them, so I designed my own.

I wanted the filament to be feed straight thru with enough room inbetween to manage any kinks or wobbles in the filament with your hands. I also wanted a better way to reduce friction thru it when near Z=0 and Z = 200+ as the filament is drug thru the horizontal position of the sensor first which is dependent on the way you install the roll (over the top or under). Thats when putting a hinge inbetween seemed like the perfect solution as I run a TUSH spool holder with the extruder feed off the bottom of the spool. I designed this Hinged Filament Sensor Mount so it can be bolted onto the Z-axis brass lead screw nut using factory hardware, then the mount is stabilized to the Z column roller mount right at the hinge. I also designed it so you could run the sensor fully enclosed or with the printed cap to keep crud out. You will need (2) M3X20 screws with (2) M3 hex nuts. Hinge is printed in place.

Please note that after printing you will need to carefully twist the built-in support material off in the same direction as the pivoting hinge. If you use flush cutter on the support material, you may end up splitting the mount in half. 

The sensor I designed this around can be purchased here:
https://macewen3d.com/products/cr-10-cr-10-s4-and-s5-replacement-endstop-limit-switch
Which is the same as the factory Creality CR-10S filament runout sensor or Axis stop sensors. My machine actually came with a spare, which made designing/refining it pretty easy. If you are retrofitting a older CR-10, you can buy the plug on amazon (#JST XH 2.54).