                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2994752
Fixed Z-axis knob for Tevo Tornado by Baard is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This design prevents the Z-axis knob from falling off when being turned in the downward direction.

You need:
1 pcs. 6800zz bearing. (10x19x5mm)
1 pcs. M2.5 screw. (5-8mm)

Instructions: (or see video below)
- Place the bearing on the knob cylinder.
- Fasten the cylinder to the knob wheel with the M2.5 screw.
- Loosen both screws that hold the lead screw bearing in place by 1mm.
-  Attach the turning knob. 
- Slide the knob mounting parts into place. Use an Allen key through the hole in the turning knob to thighten the screws. 
- You have to print 2 pcs of the knob mounting part. 


# Print Settings

Printer Brand: TEVO
Printer: Tornado
Resolution: 0.1
Infill: 50%

# Custom Section

<iframe src="//www.youtube.com/embed/VguqWmYf6qE" frameborder="0" allowfullscreen></iframe>