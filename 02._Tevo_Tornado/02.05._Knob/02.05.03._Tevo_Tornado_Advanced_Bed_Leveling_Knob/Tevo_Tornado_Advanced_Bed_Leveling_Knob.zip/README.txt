                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3006999
Tevo Tornado Advanced Bed Leveling Knob by 3Dwinther is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

Yet another bed leveling knob, but with a difference. Inspired by https://www.thingiverse.com/thing:2603493 for the CR-10, I set about to create something similar for the Tevo Tornado.

Where the CR-10 uses an M4 bolt for the bed support, the Tornado uses M5 bolts with a thread pitch of 0.8mm. This means that by dividing the circumference of the knob into 8 segments, moving the knob by 1/8 rotation will raise or lower the bed by 0.1mm. Each segment is divided into 5 sub-segments, each moving the bed by 0.02mm.

EDIT: Since there seem to be some errors in the stl file, I've had Slic3r repair it. The repaired file is TTABLK_fixed.obj (only output format of the repair function of Slic3r).

This is my first attempt at creating a 3D object and my first time using FreeCAD.
While the hole dimensions in the design are correct, I've had problems actually printing the knobs. I had to set the XY size compensation in Slic3r to -0.2 to make the knobs fit.
This unfortunately messes up the surface of the knob.

I used a white paint marker to highlight the markings and numbers. I'm not happy about the result. The white paint is quite thin and will flow along the layer lines. I recommend using something more viscous. Once I get my printer dialed in, I will re-print these.

# Print Settings

Printer Brand: TEVO
Printer: Tornado
Rafts: No
Supports: Yes
Resolution: 0.2mm
Infill: 25%

Notes: 
Depending on the accuracy of your printer, you might need to experiment with the horizontal dimension compensation of your slicer. 

# Post-Printing

Remove supports using a small screwdriver. They come off quite easily.