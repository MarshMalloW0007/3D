                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2603493
CR-10 Precision Thumbdial by idig3d is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

A more precise way to dial in your CR-10's bed. Fits over existing bed knobs. 

M4 threads have a 0.7mm pitch, so turning the knobs 1/7 of a turn will change the distance 0.1mm.

 I beveled the face and added numbers so you could read numerical adjustment. Each big point is 0.1mm. Small points are 0.02mm. Bigger numbers mean a bigger gap.

The file named "cr10_thumbdial_ws_idig3d.stl" is with support. The support is a solid ring you can snap out when the print is completed. A screwdriver may help.

*Contribute to my coffee fund if you find this useful and want to encourage my insanity. Thanks!*
[![Tip Me](http://www.idig3d.com/transfer/coffee_fund.jpg)](https://www.paypal.me/idig3d/)

# Print Settings

Printer: CR-10
Rafts: No
Supports: No
Resolution: 0.2-0.25mm layers
Infill: 25-33%

Notes: 
3 shells/perimeters. If you want you slicer to generate support, use the file without "ws" in the name.

Slow down the first layer since there are some smaller sections.

# Post-Printing

If you printed the 'ws' (With Support) version, snap out the ring.

Remove each bed knob one at a time.
Press the knob into the thumbnail. 
Screw back on the bed screw.
Repeat for all four screws.
Relevel the bed.

I usually print a few lines of a skirt around my prints and turn the dials to get the bed dialed in.