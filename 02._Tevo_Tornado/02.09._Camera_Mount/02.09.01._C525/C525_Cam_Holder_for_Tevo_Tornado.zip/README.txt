                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2739002
C525 Cam Holder for Tevo Tornado by JDM755 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Remixed to work on Tevo Tornado.

2040 Rail Mount: 
Has been designed to fit the rails on sides of Tevo Tornado and be very snug. takes a little to get on at first but holds great ad doesn't move unless you want it to. I printed mine with 100% infill for extra strength for adjustable arm. 

35mm Extension:
print multiple copies to make adjustable arm as long as you want! I made 6 for mine to start with.  Printed with 100% infill for strength. Be gentile when connecting them or you will crack the connection points. light sanding helps but not to much or it will make the connection to loose.

C525 Camera Mount:
The mount is designed to replace stock camera hinges. requires removing the 2 orange stickers on hinge side of the base to disassemble the hinge mechanism. There are 4 black screws and 1 silver screw holding the hinge mechanism. don't loose the silver screw you need that one for the new mount! Use that silver screw to attach the mount then just attach to adjustable arm. Printed with 100% infill for strength.