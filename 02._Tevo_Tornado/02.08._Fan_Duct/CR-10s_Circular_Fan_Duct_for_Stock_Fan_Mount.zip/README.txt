                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2473443
CR-10s Circular Fan Duct (for Stock Fan Mount by Prohmann is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

After upgrading to the Micro Swiss nozzle, most fan ducts I found on this site were either too thick or required the stock metal fan case to be swapped against some less stable plastic one. 
I have designed this fan duct from scratch. On the Creality CR-10s it can replace the stock fan duct. It works fine with the shorter Micro Swiss nozzle, therefore it should also work with the stock nozzle. 
There are two files included. One has a straight air intake, the other one will guide the air in the intake over a slight slope. I have no clue wether the slope will increase the effectiveness in measurable ways, so it is for you to decide which one you prefer.


# Print Settings

Printer: Creality CR-10s
Rafts: No
Supports: No
Resolution: 0.2
Infill: 25%